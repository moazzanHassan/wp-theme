<?php get_header(); // Include header.php ?>

<div id="main-content">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php 
                // Start the WordPress loop to get the page content
                if ( have_posts() ) :
                    while ( have_posts() ) : 
                        the_post(); 
                ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <header class="entry-header">
                            <h1 class="entry-title"><?php the_title(); ?></h1>
                        </header>

                        <div class="entry-content">
                            <?php 
                            // Display the page content
                            the_content(); 
                            ?>
                        </div>

                        <footer class="entry-footer">
                            <?php 
                            // Optional: You can add page metadata or navigation here.
                            edit_post_link( __( 'Edit', 'your-theme-textdomain' ), '<span class="edit-link">', '</span>' ); 
                            ?>
                        </footer>
                    </article>
                
                <?php 
                    endwhile; 
                else : 
                ?>
                    <p><?php esc_html_e( 'Sorry, no pages matched your criteria.', 'your-theme-textdomain' ); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); // Include footer.php ?>
