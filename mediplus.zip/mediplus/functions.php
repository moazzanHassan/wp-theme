<?php
function my_custom_theme_enqueue_assets() {
    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap', false);

    // Enqueue CSS files
    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css');
    wp_enqueue_style('nice-select', get_template_directory_uri() . '/css/nice-select.css');
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css');
    wp_enqueue_style('icofont', get_template_directory_uri() . '/css/icofont.css');
    wp_enqueue_style('slicknav', get_template_directory_uri() . '/css/slicknav.min.css');
    wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/css/owl-carousel.css');
    wp_enqueue_style('datepicker', get_template_directory_uri() . '/css/datepicker.css');
    wp_enqueue_style('animate', get_template_directory_uri() . '/css/animate.min.css');
    wp_enqueue_style('magnific-popup', get_template_directory_uri() . '/css/magnific-popup.css');
    wp_enqueue_style('normalize', get_template_directory_uri() . '/css/normalize.css');
    wp_enqueue_style('main-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('responsive', get_template_directory_uri() . '/css/responsive.css');

    // Enqueue JavaScript files
    wp_enqueue_script('jquery'); // jQuery is already included with WordPress

    wp_enqueue_script('jquery-migrate', get_template_directory_uri() . '/js/jquery-migrate-3.0.0.js', array('jquery'), null, true);
    wp_enqueue_script('jquery-ui', get_template_directory_uri() . '/js/jquery-ui.min.js', array('jquery'), null, true);
    wp_enqueue_script('easing', get_template_directory_uri() . '/js/easing.js', array('jquery'), null, true);
    wp_enqueue_script('colors', get_template_directory_uri() . '/js/colors.js', array(), null, true);
    wp_enqueue_script('popper', get_template_directory_uri() . '/js/popper.min.js', array(), null, true);
    wp_enqueue_script('bootstrap-datepicker', get_template_directory_uri() . '/js/bootstrap-datepicker.js', array('jquery'), null, true);
    wp_enqueue_script('jquery-nav', get_template_directory_uri() . '/js/jquery.nav.js', array(), null, true);
    wp_enqueue_script('slicknav', get_template_directory_uri() . '/js/slicknav.min.js', array(), null, true);
    wp_enqueue_script('scrollup', get_template_directory_uri() . '/js/jquery.scrollUp.min.js', array(), null, true);
    wp_enqueue_script('niceselect', get_template_directory_uri() . '/js/niceselect.js', array(), null, true);
    wp_enqueue_script('tilt', get_template_directory_uri() . '/js/tilt.jquery.min.js', array(), null, true);
    wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/js/owl-carousel.js', array(), null, true);
    wp_enqueue_script('counterup', get_template_directory_uri() . '/js/jquery.counterup.min.js', array(), null, true);
    wp_enqueue_script('steller', get_template_directory_uri() . '/js/steller.js', array(), null, true);
    wp_enqueue_script('wow', get_template_directory_uri() . '/js/wow.min.js', array(), null, true);
    wp_enqueue_script('magnific-popup', get_template_directory_uri() . '/js/jquery.magnific-popup.min.js', array(), null, true);
    
    // Counter Up CDN
    wp_enqueue_script('waypoints', 'http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js', array('jquery'), null, true);
    
    // Enqueue Bootstrap JS
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array('jquery'), null, true);
    
    // Enqueue Main JS
    wp_enqueue_script('main', get_template_directory_uri() . '/js/main.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'my_custom_theme_enqueue_assets');

function theme_features(){
    register_nav_menus(
        array(
            'primary-menu' => ('Primary Menu'),
            'footer-menu' => ('Footer Menu'),
            'useful-links' => ('Useful Links')
        )
    );
}

add_action('after_setup_theme', 'theme_features');

function my_theme_setup() {
    // Add post thumbnails
    add_theme_support('post-thumbnails');
    
    // Add custom logo support
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Add custom background support
    add_theme_support('custom-background', array(
        'default-color' => 'ffffff',
        'default-image' => get_template_directory_uri() . '/images/background.jpg',
    ));
    
    // Add custom header support
    add_theme_support('custom-header', array(
        'default-image'      => get_template_directory_uri() . '/images/header.jpg',
        'width'              => 2000,
        'height'             => 1200,
        'flex-height'        => true,
        'flex-width'         => true,
        'header-text'        => false,
    ));
    
    // Enable HTML5 markup support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Enable automatic feed links
    add_theme_support('automatic-feed-links');
    
    // Enable title tag support
    add_theme_support('title-tag');
    
    // Enable selective refresh for widgets
    add_theme_support('customize-selective-refresh-widgets');
}

add_action('after_setup_theme', 'my_theme_setup');


?>